<?php loadPart('header',$data) ?>
<?php loadPart('pageheader',$data) ?>


    <div class="content">

            
            
<!-- Blog List Start -->
<div class="container bg-white pt-5">

    <?php loadPart('show-articles',$data) ?>
    
</div>
<!-- Blog List End -->
            
            
        </div>
        
    <!-- Back to Top -->
    <a href="#" class="back-to-top"><i class="fa fa-angle-double-up"></i></a>
        
<?php loadPart('footer') ?>