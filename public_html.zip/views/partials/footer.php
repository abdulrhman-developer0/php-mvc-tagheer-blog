       
   <!-- Footer Start -->
<div class="py-4 bg-secondary text-center">
<p class="m-0 text-white">
&copy; <a class="text-white font-weight-bold" href="#">tagheer.net</a>. created by abd alrhman ahmed maher.
</p>
</div>
<!-- Footer End -->    
      
<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
<script src="lib/easing/easing.min.js"></script>
<script src="lib/waypoints/waypoints.min.js"></script>

<!-- Contact Javascript File -->
<script src="mail/jqBootstrapValidation.min.js"></script>
<script src="mail/contact.js"></script>

<!-- Template Javascript -->
<script src="js/main.js"></script>


</body>
</html>